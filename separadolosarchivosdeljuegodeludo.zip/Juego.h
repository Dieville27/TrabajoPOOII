//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_JUEGO_H
#define UNTITLED_JUEGO_H

#include <string>
#include <iostream>
using namespace std;

class Juego {
private:
    int turno;
    int numero_de_jugadores;
public:
    Juego(){
        int numero_de_jugadores;
        cout<<"Ingrese el numero de jugadores:";
        cin>>numero_de_jugadores;
        this->numero_de_jugadores = numero_de_jugadores;

    }
    void IniciarJuego();

    void AdicionarJugador(int color, string nombre);
};


#endif //UNTITLED_JUEGO_H
