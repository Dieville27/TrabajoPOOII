//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_DADO_H
#define UNTITLED_DADO_H

#include <random>
#include <iostream>
#include<string>
#include<time.h>
#include <vector>


class Dado{
public:
    int Lanzar();
};



#endif //UNTITLED_DADO_H
