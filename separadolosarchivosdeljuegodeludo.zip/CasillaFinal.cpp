//
// Created by salvador.hilares on 22/06/2019.
//

#include "CasillaFinal.h"

void CasillaFinal::mostrar() {
    color = 'F';
    tablero[getX()][getY()] = getColor();
}