//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_JUGADOR_H
#define UNTITLED_JUGADOR_H

#include <string>
#include <iostream>
#include "Ficha.cpp"
using namespace std;

class Jugador {
private:
    string nombre;
    char color;
public:
    Jugador(string nombre) {
        cout<<"Ingresa tu nombre:";
        cin>>nombre;
        this->nombre = nombre;
    }

    void jugar(Ficha *ficha, int movimientos);

    Ficha *seleccionarFichaEnJuego();
};


#endif //UNTITLED_JUGADOR_H
