//
// Created by salvador.hilares on 22/06/2019.
//

#include "CasillaInicio.h"

void CasillaInicio::mostrar() {
    color = 'I';
    tablero[getX()][getY()] = getColor();
}