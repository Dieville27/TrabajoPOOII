//
// Created by salvador.hilares on 22/06/2019.
//

#include "Juego.h"

void Juego::IniciarJuego(){}

void Juego::AdicionarJugador(int color, string nombre){
    for(int i=0 ; i<numero_de_jugadores ; i++){
        jugador
    }
}