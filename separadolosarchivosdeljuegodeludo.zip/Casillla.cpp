//
// Created by salvador.hilares on 22/06/2019.
//

#include "Casillla.h"
#include <random>
#include <iostream>
#include<string>
#include<time.h>
#include <vector>

int Casilla::getX(){
    return x;
};

int Casilla::getY(){
    return y;
}

char Casilla::getColor(){
    return color;
}