//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_FICHA_H
#define UNTITLED_FICHA_H

#include "Dado.cpp"
#include "Casillla.cpp"

class Ficha {
private:
    char estado;

public:
    Ficha(){
        estado = 'C';
    }
    void mover(Casilla* casilla);
    char getEstado();
};


#endif //UNTITLED_FICHA_H
