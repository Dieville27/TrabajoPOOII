#include <random>
#include <iostream>
#include<string>
#include<time.h>
#include <vector>
#include "Tablero.cpp"
#include "Ficha.cpp"
#include "Recorrido.cpp"
using namespace std;

int main() {
    Tablero* ludo = new Tablero;
    ludo->IngresoDatos();
    Ficha* ficha = new Ficha;
    Casilla * casillita = new CasillaCasa(0,0,'H');
    Casilla * casillita2 = new CasillaRecorrido(8,0);
    Dado* dado = new Dado;
    ficha -> mover(casillita);
    Recorrido* recorridito = new Recorrido;
    recorridito -> calcularMovimiento(casillita2, dado->Lanzar());
    cout<<dado->Lanzar()<<endl;
    ludo->mostrar();
    return 0;
}