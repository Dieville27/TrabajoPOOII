//
// Created by salvador.hilares on 22/06/2019.
//

#include "CasillaCasa.h"

void CasillaCasa::mostrar() {
    tablero[getX()][getY()] = getColor();
}