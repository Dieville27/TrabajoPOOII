//
// Created by salvador.hilares on 22/06/2019.
//

#include "CasillaRecorrido.h"

void CasillaRecorrido::mostrar() {
    color = 'R';
    tablero[getX()][getY()] = getColor();
}