//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_CASILLAINICIO_H
#define UNTITLED_CASILLAINICIO_H

#include "Casillla.cpp"

class CasillaInicio:public Casilla{
public:
    CasillaInicio(int X, int Y){
        x = X;
        y = Y;
    }
    void mostrar() override;
};


#endif //UNTITLED_CASILLAINICIO_H
