//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_TABLERO_H
#define UNTITLED_TABLERO_H

#include "Casillla.cpp"
#include "CasillaRecorrido.cpp"
#include "CasillaSegura.cpp"
#include "CasillaCasa.cpp"
#include "CasillaFinal.cpp"
#include "CasillaInicio.cpp"
#include <vector>
#include <iostream>
using namespace std;

class Tablero{
private:
    vector<Casilla*>* casillas;
public:
    Tablero(){
        tablero = new char*[15];
        for(int i=0 ;i<15 ;i++)
            tablero[i] = new char[15];
        for(int i=0 ;i<15;i++)
            for(int j=0 ;j<15 ;j++)
                tablero[i][j] = '*';
        casillas = new vector<Casilla *>();
    }
    void IngresoDatos();
    void mostrar();
};


#endif //UNTITLED_TABLERO_H
