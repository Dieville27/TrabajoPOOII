//
// Created by salvador.hilares on 22/06/2019.
//

#ifndef UNTITLED_RECORRIDO_H
#define UNTITLED_RECORRIDO_H

#include "Casillla.h"

//Clase recorrido:

class Recorrido{
public:
    void calcularMovimiento(Casilla* casilla,int movimientos);
};


#endif //UNTITLED_RECORRIDO_H
