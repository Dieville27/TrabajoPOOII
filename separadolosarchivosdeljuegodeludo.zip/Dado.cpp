//
// Created by salvador.hilares on 22/06/2019.
//

#include "Dado.h"
#include <random>
#include <iostream>
#include<string>
#include<time.h>
#include <vector>

 int Dado::Lanzar(){
     srand(time(NULL));
     int numero_dado = rand()%6+1;
     return numero_dado;
}