//
// Created by salvador.hilares on 22/06/2019.
//

#include "CasillaSegura.h"

void CasillaSegura::mostrar() {
    color = 'S';
    tablero[getX()][getY()] = getColor();
}