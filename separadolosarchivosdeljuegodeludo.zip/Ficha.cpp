//
// Created by salvador.hilares on 22/06/2019.
//

#include "Ficha.h"

void Ficha::mover(Casilla* casilla){

    Dado* dado = new Dado;

    //Este if es para mover CasillaCasa a CasillaInicio
    if ( dado->Lanzar() == 6 && estado == 'C') {
        estado = 'J';

        if((casilla -> getX()<2) && (casilla -> getY()<2)){
            tablero[6][1] = estado ;
        }
        else if ( 12< (casilla -> getX()) && (casilla -> getX())<15 && casilla -> getY()<2 ){

            tablero[13][6] = estado;

        }
        else if ( 12< (casilla -> getY()) && (casilla -> getY())<15 && casilla -> getX()<2 ){

            tablero[1][8] = estado;

        }

        else if ( 12< (casilla -> getY()) && (casilla -> getY())<15 && 12< (casilla -> getX()) && (casilla -> getX())<15 ){

            tablero[8][13] = estado;

        }

    }
    // Este if es para mover de CasillaInicio a CasillaSegura
    if(tablero[13][7] == tablero[casilla->getX()][casilla->getY()] || tablero[7][1] == tablero[casilla->getX()][casilla->getY()] || tablero[1][7] == tablero[casilla->getX()][casilla->getY()] || tablero[7][9] == tablero[casilla->getX()][casilla->getY()] ){
        estado = 'S';
    }
    // Este if es para mover de CasillaSegura A CasillaFinal
    if(tablero[7][6] == tablero[casilla->getX()][casilla->getY()] || tablero[6][7] == tablero[casilla->getX()][casilla->getY()] || tablero[7][8] == tablero[casilla->getX()][casilla->getY()] || tablero[8][7] == tablero[casilla->getX()][casilla->getY()] ){
        estado = 'F';
    }
}

char Ficha::getEstado(){
    return estado;
}