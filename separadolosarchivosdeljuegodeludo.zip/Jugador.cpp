//
// Created by salvador.hilares on 22/06/2019.
//

#include "Jugador.h"

void Jugador::jugar(Ficha *ficha, int movimientos){

}

Ficha* Jugador::seleccionarFichaEnJuego(){
    int opcion = 0;
    do {
        cout << "1. Ficha numero 1";
        cout << "2. Ficha numero 2";
        cout << "3. Ficha numero 3";
        cout << "4. Ficha numero 4";
        cout << "Ingrese la ficha que desea mover: ";
        cin >> opcion;
    } while (opcion < 0 || opcion > 4);

    switch(opcion){

        default:break;
    }
    return nullptr;
}